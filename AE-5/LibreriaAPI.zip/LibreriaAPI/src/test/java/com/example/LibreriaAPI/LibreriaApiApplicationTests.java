package com.example.LibreriaAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibreriaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
